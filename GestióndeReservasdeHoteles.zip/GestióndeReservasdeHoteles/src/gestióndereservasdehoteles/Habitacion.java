
package gestióndereservasdehoteles;

public class Habitacion {
    private String numeroHabitacion;
    private double precioNoche;
    private boolean disponible;

    public Habitacion(String numeroHabitacion, double precioNoche) {
        this.numeroHabitacion = numeroHabitacion;
        this.precioNoche = precioNoche;
        this.disponible = true; // Por defecto, la habitación está disponible
    }

    // Getters and Setters
    public String getNumeroHabitacion() {
        return numeroHabitacion;
    }

    public void setNumeroHabitacion(String numeroHabitacion) {
        this.numeroHabitacion = numeroHabitacion;
    }

    public double getPrecioNoche() {
        return precioNoche;
    }

    public void setPrecioNoche(double precioNoche) {
        this.precioNoche = precioNoche;
    }

    public boolean isDisponible() {
        return disponible;
    }

    public void setDisponible(boolean disponible) {
        this.disponible = disponible;
    }
}
