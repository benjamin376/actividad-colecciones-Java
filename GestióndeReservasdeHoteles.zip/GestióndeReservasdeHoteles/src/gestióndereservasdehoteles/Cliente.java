
package gestióndereservasdehoteles;

import java.util.ArrayList;

public class Cliente {
    private String idCliente;
    private String nombre;
    private ArrayList<Reserva> reservasRealizadas;

    public Cliente(String idCliente, String nombre) {
        this.idCliente = idCliente;
        this.nombre = nombre;
        this.reservasRealizadas = new ArrayList<>();
    }

    public void hacerReserva(Hotel hotel, Habitacion habitacion) {
        if (habitacion.isDisponible()) {
            Reserva reserva = new Reserva(hotel, habitacion);
            reservasRealizadas.add(reserva);
            habitacion.setDisponible(false); // Marca la habitación como reservada
            System.out.println("Reserva realizada en el Hotel " + hotel.getNombre() + " para la habitacion " + habitacion.getNumeroHabitacion());
        } else {
            System.out.println("La habitacion no está disponible.");
        }
    }

    // Mostrar las reservas realizadas por el cliente
    public void mostrarReservas() {
        if (reservasRealizadas.isEmpty()) {
            System.out.println("No tienes reservas realizadas.");
        } else {
            System.out.println("Reservas realizadas por " + nombre + ":");
            for (Reserva reserva : reservasRealizadas) {
                System.out.println("Hotel: " + reserva.getHotel().getNombre() + " - Habitacion: " + reserva.getHabitacionReservada().getNumeroHabitacion());
            }
        }
    }

    // Getters and Setters (opcional)
    public String getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(String idCliente) {
        this.idCliente = idCliente;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public ArrayList<Reserva> getReservasRealizadas() {
        return reservasRealizadas;
    }

    public void setReservasRealizadas(ArrayList<Reserva> reservasRealizadas) {
        this.reservasRealizadas = reservasRealizadas;
    }
}