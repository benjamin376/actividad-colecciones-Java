package gestióndereservasdehoteles;

import java.util.ArrayList;

public class Hotel {
    private String idHotel;
    private String nombre;
    private ArrayList<Habitacion> habitacionesDisponibles;

    public Hotel(String idHotel, String nombre) {
        this.idHotel = idHotel;
        this.nombre = nombre;
        this.habitacionesDisponibles = new ArrayList<>();
    }

    public void agregarHabitacion(Habitacion habitacion) {
        habitacionesDisponibles.add(habitacion);
    }

    public void mostrarHabitaciones() {
        System.out.println("Habitaciones en el Hotel " + nombre + ":");
        for (Habitacion h : habitacionesDisponibles) {
            System.out.println("Habitacion " + h.getNumeroHabitacion() + " - " + (h.isDisponible() ? "Disponible" : "No disponible") + " - Precio: " + h.getPrecioNoche());
        }
    }

    // Método para buscar un hotel por nombre
    public static Hotel buscarHotelPorNombre(ArrayList<Hotel> hoteles, String nombre) {
        for (Hotel h : hoteles) {
            if (h.getNombre().equalsIgnoreCase(nombre)) {
                return h;
            }
        }
        return null;
    }

    // Getters and Setters (opcional)
    public String getIdHotel() {
        return idHotel;
    }

    public void setIdHotel(String idHotel) {
        this.idHotel = idHotel;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public ArrayList<Habitacion> getHabitacionesDisponibles() {
        return habitacionesDisponibles;
    }

    public void setHabitacionesDisponibles(ArrayList<Habitacion> habitacionesDisponibles) {
        this.habitacionesDisponibles = habitacionesDisponibles;
    }
}