
package gestióndereservasdehoteles;

import java.util.ArrayList;
import java.util.Scanner;

public class GestióndeReservasdeHoteles {
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Crear lista de hoteles
        ArrayList<Hotel> hoteles = new ArrayList<>();

        // Crear algunos hoteles y habitaciones
        Hotel hotel1 = new Hotel("H001", "Hotel Central");
        hotel1.agregarHabitacion(new Habitacion("101", 100.0));
        hotel1.agregarHabitacion(new Habitacion("102", 120.0));

        Hotel hotel2 = new Hotel("H002", "Hotel Playa");
        hotel2.agregarHabitacion(new Habitacion("201", 200.0));
        hotel2.agregarHabitacion(new Habitacion("202", 220.0));

        hoteles.add(hotel1);
        hoteles.add(hotel2);

        // Crear cliente
        Cliente cliente1 = new Cliente("C001", "Juan Perez");

        // Menú interactivo
        int opcion;
        do {
            System.out.println("\nMenu de Gestion de Reservas:");
            System.out.println("1. Buscar hotel");
            System.out.println("2. Hacer reserva");
            System.out.println("3. Ver reservas realizadas");
            System.out.println("4. Salir");
            System.out.print("Seleccione una opcion: ");
            opcion = sc.nextInt();
            sc.nextLine();  // Consumir el salto de línea

            switch (opcion) {
                case 1:
                    System.out.print("Ingrese el nombre del hotel: ");
                    String nombreHotel = sc.nextLine();
                    Hotel hotelEncontrado = Hotel.buscarHotelPorNombre(hoteles, nombreHotel);
                    if (hotelEncontrado != null) {
                        System.out.println("Hotel encontrado: " + hotelEncontrado.getNombre());
                        hotelEncontrado.mostrarHabitaciones();
                    } else {
                        System.out.println("Hotel no encontrado.");
                    }
                    break;

                case 2:
                    System.out.print("Ingrese el nombre del hotel donde desea hacer la reserva: ");
                    nombreHotel = sc.nextLine();
                    hotelEncontrado = Hotel.buscarHotelPorNombre(hoteles, nombreHotel);
                    if (hotelEncontrado != null) {
                        hotelEncontrado.mostrarHabitaciones();
                        System.out.print("Ingrese el numero de la habitacion que desea reservar: ");
                        String numHabitacion = sc.nextLine();
                        for (Habitacion h : hotelEncontrado.getHabitacionesDisponibles()) {
                            if (h.getNumeroHabitacion().equals(numHabitacion) && h.isDisponible()) {
                                cliente1.hacerReserva(hotelEncontrado, h);
                                break;
                            }
                        }
                    } else {
                        System.out.println("Hotel no encontrado.");
                    }
                    break;

                case 3:
                    cliente1.mostrarReservas();
                    break;

                case 4:
                    System.out.println("Saliendo del sistema...");
                    break;

                default:
                    System.out.println("Opcion no válida.");
                    break;
            }
        } while (opcion != 4);
    }
}